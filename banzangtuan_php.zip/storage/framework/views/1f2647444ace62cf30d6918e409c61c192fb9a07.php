<?php $__currentLoopData = $html; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $item; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH E:\case2025\taobao\httpquanma51.com\quanma51_laravel8x\vendor\encore\laravel-admin\src/../resources/views/partials/html.blade.php ENDPATH**/ ?>