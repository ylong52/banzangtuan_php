<?php if($help): ?>
<span class="help-block">
    <i class="fa <?php echo e(\Illuminate\Support\Arr::get($help, 'icon'), false); ?>"></i>&nbsp;<?php echo \Illuminate\Support\Arr::get($help, 'text'); ?>

</span>
<?php endif; ?><?php /**PATH E:\case2025\taobao\httpquanma51.com\quanma51_laravel8x\vendor\encore\laravel-admin\src/../resources/views/form/help-block.blade.php ENDPATH**/ ?>