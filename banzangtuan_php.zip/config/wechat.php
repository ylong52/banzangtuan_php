<?php

return [
    // 商户号
    'mch_id' => '1724324234',
    
    // AppID
    'appid' => 'wx670b3f1c81071f36',

    'appsecret' => '569d6345a6b0e6b2d0075fb08a17f8a6',

    // APIv3 密钥
    'api_v3_key' => 'H4tBA6MDymDcYTxdH4tBA6MDymDcYTxd',
    
    // 商户证书序列号
    'serial_no' => '75DA1409FF9A7663457AAE6E235D262FE70295F0',
 
];
    
