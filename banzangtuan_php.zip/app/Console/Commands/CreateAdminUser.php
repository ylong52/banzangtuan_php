<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Administrator;
use Illuminate\Support\Facades\Hash;

class CreateAdminUser extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'admin:create-user {username} {password}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '创建管理员用户';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $username = $this->argument('username');
        $password = $this->argument('password');

        try {
            // 检查是否已存在该用户
            $existingUser = Administrator::where('username', $username)->first();
            
            if (!$existingUser) {
                Administrator::create([
                    'username' => $username,
                    'password' => Hash::make($password),
                    'name' => '管理员',
                    'avatar' => null,
                ]);
                
                $this->info("管理员用户 {$username} 创建成功！");
                $this->info("用户名: {$username}");
                $this->info("密码: {$password}");
            } else {
                // 更新密码
                $existingUser->update([
                    'password' => Hash::make($password),
                ]);
                
                $this->info("管理员用户 {$username} 密码已更新！");
                $this->info("用户名: {$username}");
                $this->info("密码: {$password}");
            }
            
            return 0;
        } catch (\Exception $e) {
            $this->error("创建用户失败: " . $e->getMessage());
            return 1;
        }
    }
} 