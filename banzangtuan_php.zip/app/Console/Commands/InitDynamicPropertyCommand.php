<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\DynamicProperty;

class InitDynamicPropertyCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'config:init';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '初始化动态配置数据';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->info('开始初始化动态配置数据...');

        try {
            // 清空现有数据
            DynamicProperty::where('type_tag', 'wechat')->delete();
            DynamicProperty::where('type_tag', 'payment')->delete();

            // 微信配置示例数据
            $wechatConfigs = [
                [
                    'name' => 'wechat_appid',
                    'prop_key' => 'AppID',
                    'prop_value' => '',
                    'value_type' => 'input',
                    'type_tag' => 'wechat',
                    'description' => '微信公众号AppID',
                    'sort' => 1,
                ],
                [
                    'name' => 'wechat_appsecret',
                    'prop_key' => 'AppSecret',
                    'prop_value' => '',
                    'value_type' => 'input',
                    'type_tag' => 'wechat',
                    'description' => '微信公众号AppSecret',
                    'sort' => 2,
                ],
                [
                    'name' => 'wechat_token',
                    'prop_key' => 'Token',
                    'prop_value' => '',
                    'value_type' => 'input',
                    'type_tag' => 'wechat',
                    'description' => '微信公众号Token',
                    'sort' => 3,
                ],
                [
                    'name' => 'wechat_encoding_aes_key',
                    'prop_key' => 'EncodingAESKey',
                    'prop_value' => '',
                    'value_type' => 'input',
                    'type_tag' => 'wechat',
                    'description' => '微信公众号EncodingAESKey',
                    'sort' => 4,
                ],
                [
                    'name' => 'wechat_webhook_url',
                    'prop_key' => 'Webhook URL',
                    'prop_value' => '',
                    'value_type' => 'textarea',
                    'type_tag' => 'wechat',
                    'description' => '微信公众号Webhook URL',
                    'sort' => 5,
                ],
            ];

            // 支付配置示例数据
            $paymentConfigs = [
                [
                    'name' => 'payment_api_key',
                    'prop_key' => 'API密钥',
                    'prop_value' => '',
                    'value_type' => 'input',
                    'type_tag' => 'payment',
                    'description' => '支付API密钥',
                    'sort' => 1,
                ],
                [
                    'name' => 'payment_merchant_id',
                    'prop_key' => '商户ID',
                    'prop_value' => '',
                    'value_type' => 'input',
                    'type_tag' => 'payment',
                    'description' => '支付商户ID',
                    'sort' => 2,
                ],
                [
                    'name' => 'payment_wechat_mchid',
                    'prop_key' => '微信商户号',
                    'prop_value' => '',
                    'value_type' => 'input',
                    'type_tag' => 'payment',
                    'description' => '微信支付商户号',
                    'sort' => 3,
                ],
                [
                    'name' => 'payment_alipay_app_id',
                    'prop_key' => '支付宝应用ID',
                    'prop_value' => '',
                    'value_type' => 'input',
                    'type_tag' => 'payment',
                    'description' => '支付宝应用ID',
                    'sort' => 4,
                ],
                [
                    'name' => 'payment_notify_url',
                    'prop_key' => '支付回调地址',
                    'prop_value' => '',
                    'value_type' => 'textarea',
                    'type_tag' => 'payment',
                    'description' => '支付回调地址',
                    'sort' => 5,
                ],
                [
                    'name' => 'payment_types',
                    'prop_key' => '支付类型',
                    'prop_value' => 'wechat,alipay',
                    'value_type' => 'select',
                    'type_tag' => 'payment',
                    'description' => '支持的支付类型',
                    'sort' => 6,
                ],
            ];

            // 插入数据
            foreach ($wechatConfigs as $config) {
                $config['updated_at'] = now();
                DynamicProperty::create($config);
            }

            foreach ($paymentConfigs as $config) {
                $config['updated_at'] = now();
                DynamicProperty::create($config);
            }

            $this->info('动态配置数据初始化完成！');
            $this->info('已创建 ' . count($wechatConfigs) . ' 个微信配置项');
            $this->info('已创建 ' . count($paymentConfigs) . ' 个支付配置项');
            
            return 0;
        } catch (\Exception $e) {
            $this->error('初始化失败：' . $e->getMessage());
            return 1;
        }
    }
}
