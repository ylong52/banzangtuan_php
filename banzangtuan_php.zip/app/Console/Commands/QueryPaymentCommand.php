<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

use Illuminate\Support\Facades\Cache;
use App\Models\RechargeRecord;
use App\Services\AyqySignService;
use App\Services\PaymentOrderService; 
use App\Services\DynamicPropertyService;
use App\Models\User;
use App\Models\UserWithdrawal;

class QueryPaymentCommand extends Command
{
    protected $signature = 'payment:query';

    protected $description = '查询支付状态,修改订单状态';

    public function handle()
    {
        $this->info('开始查询支付状态...');
        $this->QueryOrderStatus();
        sleep(3);
        $this->batchUpdateStatus();
        sleep(3);
        $this->info('查询支付状态完成...');
    }

    //用户充值--查询支付状态
    
    private function QueryOrderStatus() {
        //控制15秒才能执行一次
        $last_time = Cache::get('QueryOrderStatus_last_time');
        if($last_time && time() - $last_time < 15){
            return;
        }
        Cache::put('QueryOrderStatus_last_time',time());
       
        //状态:0-待支付,1-支付成功,2-支付失败
        $paymentService = new PaymentOrderService();
        try {
            $list = RechargeRecord::query()
            ->where('status',"<>",1)   
            ->where("third_party_order_no","<>","")   
            ->where("created_at",">=",date('Y-m-d 00:00:00'))      
            ->select("order_no","third_party_order_no")->orderBy('created_at','desc')
            ->get()->toArray();
    
            //状态:0-待支付,1-支付成功,2-支付失败
            foreach($list as $item){         
                $this->info('开始查询支付状态...'.$item['third_party_order_no']);   
                $orderRetState = $paymentService->FeixpayQueryOrder($item['third_party_order_no']);   

                $rechargeRecord = RechargeRecord::where('order_no',$item['order_no'])->first();   
                
var_dump("57>>> rechargeRecord==",$rechargeRecord->toArray());         
var_dump("58>>> FeixpayQueryOrder orderRetState==",$orderRetState);   
                if (!empty($orderRetState['error'])) {
                    //错误
                    $rechargeRecord->status = 2;
                    $rechargeRecord->payment_time = date('Y-m-d H:i:s');
                    $rechargeRecord->updated_at = date('Y-m-d H:i:s');
                    $rechargeRecord->errormsg = $orderRetState['msg']??'';
                    $rechargeRecord->save();
                    continue;
                } else if ($orderRetState['state'] == 3) {
                    //3表示支付成功                    
                    $rechargeRecord->status = 1;
                    $rechargeRecord->payment_time = date('Y-m-d H:i:s');   
                    $rechargeRecord->updated_at = date('Y-m-d H:i:s');
                    $rechargeRecord->errormsg = '支付成功';
                    $rechargeRecord->save();
                    $this->RechargeAddBalance_log($rechargeRecord);     
                } else if (in_array($orderRetState['state'],[0,1,2,4,5])) {
                    //其他状态，不做处理
                    $rechargeRecord->status = 2;
                    $rechargeRecord->payment_time = date('Y-m-d H:i:s');
                    $rechargeRecord->updated_at = date('Y-m-d H:i:s');
                    $rechargeRecord->errormsg = $orderRetState['msg']??'';
                    if ($orderRetState['state']==0) {
                        $rechargeRecord->errormsg = '支付失败';
                    } else if ($orderRetState['state']==1) {
                        $rechargeRecord->errormsg = '初始化';
                    } else if ($orderRetState['state']==2) {
                        $rechargeRecord->errormsg = '支付中';
                    } else if ($orderRetState['state']==4) {
                        $rechargeRecord->errormsg = '已撤销';
                    } else if ($orderRetState['state']==5) {
                        $rechargeRecord->errormsg = '订单关闭';
                    }
                    $rechargeRecord->save();
                }
            }
        } catch (\Exception $e) {
            
            // dump("125 >>>",$e->getMessage());
            $this->info('查询订单状态失败 QueryOrderStatus::'.$e->getMessage());
        }
    }

    // //更新用户余额日志
    private function RechargeAddBalance_log($rechargeRecordInfo)
    {       
        $userInfo = User::where('id', $rechargeRecordInfo->user_id)->first();

        if ($userInfo) {
            $balance_before = intval($userInfo->balance);
            $balance_after = $balance_before + $rechargeRecordInfo->amount;
        }
        $user_balance_log = new \App\Models\UserBalaceLog();
        $user_balance_log->order_id = $rechargeRecordInfo->id;
        $user_balance_log->user_id = $rechargeRecordInfo->user_id;
        $user_balance_log->amount = $rechargeRecordInfo->amount;
        $user_balance_log->transaction_type = 1; //1表示充值
        $user_balance_log->balance_before = $balance_before;
        $user_balance_log->balance_after = $balance_after;
        $user_balance_log->transaction_no = $rechargeRecordInfo->third_party_order_no;
        $user_balance_log->remark = '充值' . $rechargeRecordInfo->amount;
        $user_balance_log->created_at = date('Y-m-d H:i:s');
        $user_balance_log->save();
        //更新用户余额
        $userInfo->balance = $balance_after;
        $userInfo->save();
        echo "$userInfo->username 充值成功<br>";
    }


    //用户提现--批量更新提现状态
    //用于微信的用户确认提现
    public function batchUpdateStatus() {
        //1.将status=3 的订单, withdrawal_time已经超过了24小时。将status=4，设为过期
        // 使用正确的微信转账服务查询状态
        //提现状态:0-待处理,1-已到账,2-失败,3-未确认收款(微信)
        $transferService = new \App\Services\WechatTransferService();  
        $list = UserWithdrawal::query()
        ->where('withdrawal_time',">=",date('Y-m-d 00:00:00'))
        ->whereIn('withdrawal_status', [0,2,3])
        ->get();
        
        foreach ($list as $item) {
            //微信的                         
            $statusResult = $transferService->queryTransferStatus($item->withdrawal_no);
         
            if ($statusResult['state']=='WAIT_USER_CONFIRM') {
                continue;
            }
            if (!empty($statusResult) || $statusResult['state']=='SUCCESS') {
                
                $item->withdrawal_status = 1;
                $item->arrival_time = time();
                $item->save();
                $user = \App\Models\User::find($item->user_id);
                $userBalanceLog = new \App\Models\UserBalaceLog();
                $userBalanceLog->user_id = $item->user_id;
                $userBalanceLog->order_id = $item->id;
                $userBalanceLog->transaction_type = 3;
                $userBalanceLog->amount = $item->amount;
                $userBalanceLog->balance_before = $user->balance;
                $userBalanceLog->balance_after = $user->balance;
                $userBalanceLog->transaction_no = $item->withdrawal_no;
                $userBalanceLog->remark = '微信提现已经确认,已到账';
                $userBalanceLog->created_at = date('Y-m-d H:i:s');
                $userBalanceLog->save();
            } elseif ($statusResult['state']!='SUCCESS' && $statusResult['state']=='WAIT_USER_CONFIRM') {
                $item->withdrawal_status = 2;
                $item->save();
                //回退余额
                $user = \App\Models\User::find($item->user_id);
                $user->balance = $user->balance + $item->amount;
                $user->save();
                $userBalanceLog = new \App\Models\UserBalaceLog();
                $userBalanceLog->user_id = $item->user_id;
                $userBalanceLog->order_id = $item->id;
                $userBalanceLog->transaction_type = 3;
                $userBalanceLog->amount = $item->amount;
                $userBalanceLog->balance_before = $user->balance;
                $userBalanceLog->balance_after = $user->balance;
                $userBalanceLog->transaction_no = $item->withdrawal_no;
                $userBalanceLog->remark = '微信提现用户超24小时未确认,已回退';
                $userBalanceLog->created_at = date('Y-m-d H:i:s');
                $userBalanceLog->save();
            }
        }

    }



}
