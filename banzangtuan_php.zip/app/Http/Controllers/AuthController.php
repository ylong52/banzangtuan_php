<?php

namespace App\Http\Controllers;

use App\Models\GlobalConfig;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use SebastianBergmann\CliParser\AmbiguousOptionException;

class AuthController extends Controller
{
    public function register(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'username' => 'required|string|max:255|unique:users',
            // 'phone' => 'required|string|max:11|unique:users',
            'password' => 'required|string|min:6',
        ], [
            'username.required' => '用户名不能为空',
            'username.max' => '用户名不能超过255个字符',
            'username.unique' => '用户名已存在',
            // 'phone.required' => '手机号不能为空',
            // 'phone.max' => '手机号不能超过11个字符',
            // 'phone.unique' => '手机号已经注册',
            'password.required' => '密码不能为空',
            'password.min' => '密码不能小于6个字符',
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors()->all();
            $firstError = count($errors) > 0 ? $errors[0] : '注册失败';
            return response()->json([
                'status' => 'error',
                'message' => $firstError
            ], 400);
        }

        $max_id = User::withTrashed()->max('id');
        if (empty($max_id) || $max_id < 10000) {
            $current_id = 10000;
        } else {
            $current_id = $max_id + 1;
        }
        DB::beginTransaction();
        try {
            $user = User::create([
                'id' => $current_id,
                'username' => $request->username,
                // 'phone' => $request->phone,
                'password' => Hash::make($request->password),
            ]);
            $invite  = $request->invite;
       
            if (!empty($invite)) {       
                //核对一下
                $count = User::where('id', $invite)->count();               
                if ($count > 0) {                    
                    //新增推广记录
                    $invite_amount = \App\Models\GlobalConfig::where(['status'=>1,'key'=>'invite_amount'])->value('value');
                    $promotion = new \App\Models\Promotion();
                    $promotion->user_id = $user->id;  //新用户
                    $promotion->referred_by = $invite;  //推荐人
                    $promotion->referral_code = $invite;  //推荐人
                    $promotion->registration_time = date('Y-m-d H:i:s');
                    $promotion->reward_amount = $invite_amount;
                    $promotion->reward_status = 1;  //1已发放
                    $promotion->save();
                    //更新用户余额日志  
                    $this->updateuser_balance_log($user->id, $invite);

                }
                              
            }
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'status' => 'error',
                'message' => $e->getMessage()
            ], 500);
        }
        $userInfo = User::where('id',$user->id)->first()->makeHidden(['password','deleted_at','created_at','updated_at','balance_password']);
        DB::commit();
        if ($user) {
            return response()->json([
                'status' => 'success',
                'message' => '注册成功',
                'data' => $userInfo
            ], 200);
        } else {
            return response()->json([
                'status' => 'error',
                'message' => '注册失败'
            ], 500);
        }
    }

    // //更新用户余额日志
    private function updateuser_balance_log($new_user_id, $referral_code)
    {
        $amount =  GlobalConfig::where("key","invite_amount")->value('value');
        if (!$amount) {
            $amount = 0;
        }
        $userInfo = User::where('id', $referral_code)->first();
        if ($userInfo) {
            $balance_before = $userInfo->balance;
            $balance_after = $balance_before + $amount;
        }
        $user_balance_log = new \App\Models\UserBalaceLog();
        $user_balance_log->user_id = $referral_code;
        $user_balance_log->amount = $amount;
        $user_balance_log->transaction_type = 4;
        $user_balance_log->balance_before = $balance_before;
        $user_balance_log->balance_after = $balance_after;
        $user_balance_log->transaction_no = '';
        $user_balance_log->remark = '推荐' . $new_user_id . '注册奖励';
        $user_balance_log->created_at = date('Y-m-d H:i:s');
        $user_balance_log->save();
        //更新用户余额
        $userInfo->balance = $balance_after;
        $userInfo->save();
    }


    public function login(Request $request)
    {
        // 61行开始
        try {
            $credentials = $request->validate([
                'username' => 'required|string|min:6',
                'password' => 'required',
            ], [
                'username.required' => '用户名不能为空',
                'username.min' => '用户名不能小于6个字符',
                'username.max' => '用户名不能超过255个字符',
                'password.required' => '密码不能为空',
            ]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            // 只取第一个错误信息
            $firstError = collect($e->errors())->flatten()->first();
            return response()->json([
                'code' => 422,
                'msg' => $firstError // 只返回第一个错误字符串
            ], 422);
        }

        if (Auth::attempt($credentials)) {
            $user = Auth::user();
            // 生成一个有效期为7天的token（可用Laravel Sanctum/Passport，或自定义token）
            if (method_exists($user, 'createToken')) {
                $token = $user->createToken('api-token', ['*'], now()->addDays(7))->plainTextToken;
            } else {
                throw new \Exception('User模型未正确配置API令牌功能');
            }
            $userInfo = User::where('id',$user->id)->select('id','username','phone','balance')->where('deleted_at',null)->first();
            return response()->json([
                'status' => 'success',
                'message' => '登录成功',
                'data' => [
                    'token' => $token,
                    'token_type' => 'Bearer',
                    'expires_in' => 60 * 60 * 24 * 7, // 7天（秒）
                    'user' => $userInfo
                ]
            ], 200);
        } else {
            return response()->json([
                'code' => 401,
                'msg' => '用户名或密码错误'
            ], 401);
        }
    }


    public function logout()
    {
        auth()->user()->tokens()->delete();
        return response()->json(['message' => 'Logged out successfully']);
    }

    //忘记密码
    public function forgotPassword(Request $request)
    {        
        $validator = Validator::make($request->all(), [
            'phone' => 'required|string|max:11',
            'password' => 'required|string|min:6',
            'verify_code' => 'required',
        ], [
            'phone.required' => '手机号不能为空',
            'phone.max' => '手机号不能超过11个字符',
            'password.required' => '新密码不能为空',
            'password.min' => '新密码不能小于6个字符',
            'verify_code.required' => '验证码不能为空',
        ]);
                
        if ($validator->fails()) {
            $errors = $validator->errors()->all();
            $firstError = count($errors) > 0 ? $errors[0] : '重置密码失败';
            return response()->json([
                'status' => 'error',
                'message' => $firstError
            ], 400);
        }
        
        // 查找用户
        $user = User::where('phone', $request->phone)->first();
        if (!$user) {
            return response()->json([
                'status' => 'error',
                'message' => '该手机号未注册'
            ], 404);
        }
        
        // 验证验证码
        if ($request->verify_code != '888888' && !$this->verifyCode($request->phone, $request->verify_code)) {
            return response()->json([
                'status' => 'error',
                'message' => '验证码错误或已过期'
            ], 400);
        }
        
        try {
            // 更新密码
            $user->password = Hash::make($request->password);
            $user->save();
            
            return response()->json([
                'status' => 'success',
                'message' => '密码重置成功'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => '密码重置失败：' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * 发送验证码
     */
    public function sendVerifyCode(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'phone' => 'required|string|max:11',
        ], [
            'phone.required' => '手机号不能为空',
            'phone.max' => '手机号不能超过11个字符',
        ]);
        
        if ($validator->fails()) {
            $errors = $validator->errors()->all();
            $firstError = count($errors) > 0 ? $errors[0] : '发送验证码失败';
            return response()->json([
                'status' => 'error',
                'message' => $firstError
            ], 400);
        }
        
        // 查找用户
        $user = User::where('phone', $request->phone)->first();
        if (!$user) {
            return response()->json([
                'status' => 'error',
                'message' => '该手机号未注册，请先注册'
            ], 200);
        }
        
        try {
            // 生成6位随机验证码
            $code = mt_rand(100000, 999999);
            
            // 存储验证码到缓存或数据库
            // 这里使用Redis缓存，设置5分钟过期
            \Illuminate\Support\Facades\Redis::setex('verify_code:' . $request->phone, 300, $code);
            
            // 发送短信验证码
            // 这里应该调用短信服务API发送验证码
            // 例如：$this->sendSms($request->phone, $code);
            
            return response()->json([
                'status' => 'success',
                'message' => '验证码已发送',
                'code' => $code, // 实际生产环境中应该移除此行，这里仅为测试方便
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => '发送验证码失败：' . $e->getMessage()
            ], 500);
        }
    }
    
    // 验证码验证方法
    private function verifyCode($phone, $code)
    {
        // 从缓存或数据库中获取之前发送的验证码
        $storedCode = \Illuminate\Support\Facades\Redis::get('verify_code:' . $phone);
        
        // 验证码比对
        if ($storedCode && $storedCode == $code) {
            // 验证成功后删除缓存中的验证码
            \Illuminate\Support\Facades\Redis::del('verify_code:' . $phone);
            return true;
        }
        
        return false;
    }

    /**
     * 修改密码
     */
    public function changePassword(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'old_password' => 'required|string',
            'new_password' => 'required|string|min:6',
        ], [
            'old_password.required' => '当前密码不能为空',
            'new_password.required' => '新密码不能为空',
            'new_password.min' => '新密码不能小于6个字符',
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors()->all();
            $firstError = count($errors) > 0 ? $errors[0] : '修改密码失败';
            return response()->json([
                'status' => 'error',
                'message' => $firstError
            ], 400);
        }

        $user = Auth::user();

        if (!Hash::check($request->old_password, $user->password)) {
            return response()->json([
                'status' => 'error',
                'message' => '旧密码错误'
            ], 400);
        }

        try {
            $user->password = Hash::make($request->new_password);
            $user->save();

            return response()->json([
                'status' => 'success',
                'message' => '密码修改成功'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => '密码修改失败：' . $e->getMessage()
            ], 500);
        }
    }

 

}
